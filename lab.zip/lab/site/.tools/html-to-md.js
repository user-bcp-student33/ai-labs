// Quick-and-dirty HTML -> Markdown converter for the cloned lab guide pages.
// Not a full HTML parser: good enough to turn the rendered guide into readable text.
const fs = require('fs');
const path = require('path');

function decodeEntities(s) {
  return s
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&#x27;/g, "'");
}

function htmlToMarkdown(html) {
  // Keep only the <main>...</main> region (actual guide content, skips header/nav chrome).
  const mainMatch = html.match(/<main[^>]*>([\s\S]*)<\/main>/i);
  let body = mainMatch ? mainMatch[1] : html;

  body = body.replace(/<script[\s\S]*?<\/script>/gi, '');
  body = body.replace(/<style[\s\S]*?<\/style>/gi, '');
  body = body.replace(/<svg[\s\S]*?<\/svg>/gi, '');

  // Fenced code blocks first (pre > code).
  body = body.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_, inner) => {
    const text = decodeEntities(inner.replace(/<[^>]+>/g, ''));
    return '\n```\n' + text.trim() + '\n```\n';
  });

  body = body.replace(/<h1[^>]*>([\s\S]*?)<\/h1>/gi, (_, t) => '\n# ' + strip(t) + '\n');
  body = body.replace(/<h2[^>]*>([\s\S]*?)<\/h2>/gi, (_, t) => '\n## ' + strip(t) + '\n');
  body = body.replace(/<h3[^>]*>([\s\S]*?)<\/h3>/gi, (_, t) => '\n### ' + strip(t) + '\n');
  body = body.replace(/<h4[^>]*>([\s\S]*?)<\/h4>/gi, (_, t) => '\n#### ' + strip(t) + '\n');

  body = body.replace(/<li[^>]*>([\s\S]*?)<\/li>/gi, (_, t) => '\n- ' + strip(t));
  body = body.replace(/<code[^>]*>([\s\S]*?)<\/code>/gi, (_, t) => '`' + strip(t) + '`');
  body = body.replace(/<strong[^>]*>([\s\S]*?)<\/strong>/gi, (_, t) => '**' + strip(t) + '**');
  body = body.replace(/<b[^>]*>([\s\S]*?)<\/b>/gi, (_, t) => '**' + strip(t) + '**');
  body = body.replace(/<em[^>]*>([\s\S]*?)<\/em>/gi, (_, t) => '_' + strip(t) + '_');
  body = body.replace(/<a[^>]+href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi, (_, href, t) => {
    const text = strip(t) || href;
    return `[${text}](${href})`;
  });
  body = body.replace(/<\/p>/gi, '\n\n');
  body = body.replace(/<br\s*\/?>/gi, '\n');

  function strip(s) {
    return decodeEntities(s.replace(/<[^>]+>/g, '')).trim();
  }

  body = strip(body);
  body = body.replace(/\n{3,}/g, '\n\n');
  return body.trim() + '\n';
}

const [,, inPath, outPath] = process.argv;
const html = fs.readFileSync(inPath, 'utf8');
const md = htmlToMarkdown(html);
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, md, 'utf8');
console.log('Wrote', outPath, md.length, 'chars');
