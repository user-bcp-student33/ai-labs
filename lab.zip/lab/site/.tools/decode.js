// Decodes a Playwright tool-result dump (JSON-encoded string, prefixed with "Result: ") into raw HTML.
const fs = require('fs');
const [,, inPath, outPath] = process.argv;
let raw = fs.readFileSync(inPath, 'utf8');
if (raw.startsWith('Result: ')) raw = raw.slice('Result: '.length);
if (!raw.startsWith('"')) throw new Error('Expected JSON string literal at start of file');
// Scan the JSON string literal manually, ignoring any trailing text appended after it (e.g. page snapshot dumps).
let i = 1;
let out = '';
while (i < raw.length) {
  const ch = raw[i];
  if (ch === '"') { i++; break; }
  if (ch === '\\') {
    const next = raw[i + 1];
    const map = { n: '\n', t: '\t', r: '\r', '"': '"', '\\': '\\', '/': '/', b: '\b', f: '\f' };
    if (next === 'u') {
      out += String.fromCharCode(parseInt(raw.slice(i + 2, i + 6), 16));
      i += 6;
    } else {
      out += map[next] !== undefined ? map[next] : next;
      i += 2;
    }
    continue;
  }
  out += ch;
  i++;
}
fs.mkdirSync(require('path').dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, out, 'utf8');
console.log('Wrote', outPath, out.length, 'chars');
