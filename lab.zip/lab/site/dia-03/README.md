**15 de 15** pasos completados

100%xGuardando en tu cuenta…

Pasos del laboratorioSDD: del Issue al PR

Ver un pasoCompletado

S1 · Paso 1 de 15

# Preparar OpenSpec en ai-labs
Instala la CLI, inicializa seleccionando GitHub Copilot, conserva el schema estándar spec-driven y configura el contexto/reglas del laboratorio.

Prepara OpenSpec para trabajar sobre ai-labs y el componente elegido con GitHub Copilot y el schema spec-driven.

En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

- Comprueba Node.js e instala la CLI.
- Inicializa ai-labs con GitHub Copilot seleccionado.
- Revisa la configuración generada y agrega el contexto del producto sin borrar propiedades existentes.
### Resultado esperado

- El repositorio debe tener la estructura OpenSpec, la integración en .github/ y una configuración que conserve el flujo proposal → specs → design → tasks → apply.
### Comprobar la versión de Node.js
Muestra qué versión de Node.js encuentra tu terminal. OpenSpec necesita Node.js para ejecutar su CLI. En Git Bash de tu equipo, antes de instalar OpenSpec.

Comando
```
node --version
```

### Instalar la CLI de OpenSpec
Descarga e instala OpenSpec para que el comando openspec esté disponible en tu equipo. Esta instrucción prepara la herramienta; la configuración de ai-labs se crea después con openspec init. En Git Bash de tu equipo, con Node.js y npm instalados y acceso al registro de npm.

Comando
```
npm install -g @fission-ai/openspec@latest
```

### Comprobar la instalación de OpenSpec
Consulta la versión de la CLI instalada para confirmar que tu terminal puede encontrar y ejecutar OpenSpec. En Git Bash de tu equipo, dentro del repositorio local del Issue.

Comando
```
openspec --version
```

### Inicializar OpenSpec en ai-labs
Prepara la estructura de OpenSpec y los workflows de GitHub Copilot dentro de ai-labs. En tu repositorio local del Issue. El repositorio actual es ai-labs. Selecciona GitHub Copilot al inicializar OpenSpec.

Comando
```
openspec init
```

### Consultar los cambios de OpenSpec
Lista los cambios activos que OpenSpec reconoce en este repositorio. Sirve para identificar el nombre del cambio que usarás en status y validate. En la raíz de tu repositorio local, después de inicializar OpenSpec.

Comando
```
openspec list
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S1 · Paso 2 de 15

# Crear el Project backlog-ai-labs y elegir un Issue (estado Todo)
Crea el Project nuevo backlog-ai-labs, crea el issue con el texto de este paso, asócialo al Project y confirma que quede en Todo.

Reúne tus issues de ai-labs en un Project propio, backlog-ai-labs, para elegir el trabajo que gobernará el recorrido con su origen y trazabilidad.

En GitHub para crear el Project, en Copilot con PM/PO para asociar y consultar los issues, y en tu ai-labs local para preparar la rama.

- Crea el Project nuevo: en GitHub abre tu perfil, entra en Projects, pulsa New project, elige la plantilla Table, escribe el nombre backlog-ai-labs y pulsa Create project.
- En la tabla del Project pulsa + al final de las columnas, elige New field, escribe Hallazgo origen, selecciona el tipo Text y guarda. Conserva el campo Status con sus opciones Todo, In Progress y Done.
- Abre https://github.com//ai-labs/issues/new, pega el título y la descripción del issue de este paso y pulsa Create. Anota su número.
- Asocia ese issue con el prompt «Asociar tu issue al Project», indicando su número.
- Consulta los items del Project backlog-ai-labs y confirma que tu issue aparece en Todo con Hallazgo origen H-AUTH-01.
- Crea la rama vinculada al issue y confirma que esté activa.
### Resultado esperado

- Conserva el número y enlace del Issue, su H-AUTH-NN, H-API-NN o H-WEB-NN y el nombre de la rama. Todos los artefactos posteriores deben referirse a ese mismo cambio.
### Si algo no coincide

- No reutilices Projects ReqFlow u otros que haya dejado otro grupo en la misma cuenta: crea backlog-ai-labs.
- Si Copilot no muestra tools de escritura de Projects, comprueba el toolset projects de github-official o agrega el issue desde el Project con + Add item, escribiendo # y eligiendo ai-labs.
### Título del issue
Copia este título al crear el issue en tu repositorio ai-labs. En GitHub, en https://github.com/<OWNER>/ai-labs/issues/new.

Archivo
```
H-AUTH-01 Usar consultas parametrizadas en el login de auth
```

### Descripción del issue
Copia esta descripción completa en el issue. Cumple el formato del recorrido: Origen con el Id y la evidencia archivo:línea, Contexto y Criterios de aceptación verificables. En GitHub, en el cuerpo del issue nuevo.

Archivo
```
## Origen

- Hallazgo origen: H-AUTH-01
- Componente: auth
- Tipo: Vulnerabilidad, severidad alta
- Evidencia: auth/src/main/java/com/bcp/workshop/auth/LegacyDatabase.java:32

## Contexto

`LegacyDatabase.findByCredentials` arma la consulta SQL concatenando `username` y `password`. Un valor como `' OR '1'='1` cambia la consulta y permite iniciar sesión sin conocer la contraseña. El cambio se limita a `auth/` y conserva el contrato de `POST /auth/login`.

## Criterios de aceptación

- [ ] `findByCredentials` usa `PreparedStatement` con parámetros para `username` y `password`; no concatena valores en el SQL.
- [ ] `POST /auth/login` con `student` y `Workshop123!` sigue respondiendo 200 con `user.username` y `token`.
- [ ] `POST /auth/login` con `' OR '1'='1` como usuario o contraseña responde 401 y no devuelve `token`.
- [ ] `AuthResourceTest` incluye una prueba del intento de inyección y `mvn test` pasa desde `auth/`.
```

### Asociar tu issue al Project
Agrega al Project backlog-ai-labs el issue de ai-labs que vas a trabajar, sin crear otro, y completa su Hallazgo origen y su estado. En GitHub Copilot Chat de VS Code. Selecciona PM/PO.

Prompt
```
Usando exclusivamente el GitHub MCP oficial, agrega el issue # de
/ai-labs al GitHub Project "backlog-ai-labs" del owner .

Reglas:
- no crees issues nuevos ni cambies el repositorio, título o descripción del issue;
- completa el campo "Hallazgo origen" con el ID H-AUTH-NN, H-API-NN o H-WEB-NN
  que aparece en su descripción; si no lo encuentras, déjalo vacío y avísame;
- deja el campo Status en Todo.
```

### Consultar los items del Project backlog-ai-labs
Comprueba por MCP que tu issue de ai-labs quedó en el Project backlog-ai-labs. En GitHub Copilot Chat de VS Code. Selecciona PM/PO.

Prompt
```
Usando exclusivamente el GitHub MCP oficial, consulta el GitHub Project "backlog-ai-labs"
del owner  y lista sus items: repositorio, título, estado y campo
"Hallazgo origen".

No crees ni modifiques nada en esta consulta.
No uses terminal ni GitHub CLI.
```

### Identificar el Project correcto
Confirma la identidad del Project para que las operaciones siguientes apunten al Project backlog-ai-labs correcto. En GitHub Copilot Chat de VS Code. Selecciona PM/PO.

Prompt
```
Usando exclusivamente github-official, lista los GitHub Projects de  y confirma el número o identificador del Project backlog-ai-labs.
```

### Entrar en el repositorio de ai-labs
Cambia el directorio de trabajo de la terminal a la raíz de ai-labs para que las operaciones siguientes se hagan en el repositorio correcto. Desde la carpeta personal del curso. Si ya estás en la raíz de ai-labs, omite este comando.

Comando
```
cd ai-labs
```

### Crear la rama vinculada al Issue
Pide a GitHub una rama de desarrollo vinculada al Issue elegido y deja esa rama activa en tu copia local de ai-labs. En el clon local de ai-labs, con gh autenticado y permisos para crear ramas en ese repositorio.

Comando
```
gh issue develop  --checkout --base main --name 
```

### Comprobar la rama activa
Muestra el nombre de la rama local actual para confirmar dónde se guardarán tus cambios. En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

Comando
```
git branch --show-current
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S1 · Paso 3 de 15

# Crear proposal + specs/ desde el Issue
Genera el contrato de cambio (qué se cambia, criterios, no-funcionales) antes de implementar. Pasa por GATE HUMANO antes de continuar a S2.

Define por qué importa el cambio y qué comportamiento se espera antes de decidir cómo implementarlo.

En Copilot con PM/PO, limitado al componente elegido.

- Consulta el Issue y el contrato documentado.
- Crea proposal y specs con alcance, fuera de alcance y escenarios observables.
- Revisa y aprueba los artefactos antes de pasar al diseño.
### Resultado esperado

- El cambio debe referenciar el Issue y especificar qué se preserva o cambia. Todavía no deben añadirse design, tasks ni código funcional en esta etapa.
### Crear proposal y specs desde el Issue
Convierte el Issue aprobado en una propuesta de cambio y escenarios verificables antes de diseñar o implementar. En GitHub Copilot Chat de VS Code. Selecciona PM/PO.

Prompt
```
Trabaja en la raíz de ai-labs.
Identifica el componente del Issue: auth/, api/ o web/.
Limita el código y las pruebas al componente elegido; conserva las secciones de los demás componentes en los documentos generales.
Git, MCP y OpenSpec se ejecutan desde la raíz; las pruebas usan el directorio del componente.

Trabaja sobre la rama actual.
No crees ni cambies de rama.

Usa github-official para consultar el GitHub Issue #
y úsalo como fuente del trabajo comprometido y del alcance.

Trabaja con OpenSpec y el schema estándar spec-driven configurado en este repositorio.

Usa github-official para consultar el Issue y úsalo como fuente del trabajo comprometido y del alcance.
Usa docs/ENDPOINTS.md (contrato documentado el Dia 1) como baseline del comportamiento que debe preservarse: los escenarios de las specs deben ser coherentes con ese contrato, o explicar por que el Issue lo cambia.

Crea una propuesta OpenSpec para este cambio y materializa:
- proposal.md;
- las specs necesarias bajo openspec/changes//specs/.

La propuesta debe:
- referenciar el Issue;
- explicar por qué importa el cambio;
- separar alcance y fuera de alcance;
- identificar comportamiento que debe preservarse;
- definir requisitos verificables y escenarios observables.

No diseñes todavía la implementación técnica.
No crees tasks.md todavía.
No modifiques código funcional.
```

### Consultar los cambios de OpenSpec
Lista los cambios activos que OpenSpec reconoce en este repositorio. Sirve para identificar el nombre del cambio que usarás en status y validate. En la raíz de tu repositorio local, después de inicializar OpenSpec.

Comando
```
openspec list
```

### Revisar el estado de los artefactos
Consulta qué artefactos del cambio están disponibles y cuáles siguen pendientes según el workflow de OpenSpec. En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

Comando
```
openspec status --change 
```

### Validar los artefactos del cambio
Comprueba las reglas de estructura y contenido que OpenSpec aplica a las especificaciones del cambio seleccionado. En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

Comando
```
openspec validate 
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 4 de 15

# Crear design.md (Plan)
Decisiones técnicas, impacto, estrategia incremental y riesgos.

Convierte las specs aprobadas en decisiones técnicas que permitan un cambio acotado.

En Copilot con Architect, en la misma rama.

- Lee proposal y specs antes de diseñar.
- Documenta componentes, contratos, alternativas, riesgos y estrategia incremental.
- Identifica qué pruebas deben proteger el comportamiento antes del cambio.
### Resultado esperado

- design.md debe explicar las decisiones necesarias para ese Issue y permitir revisar sus riesgos sin ampliar el alcance.
### Diseñar el cambio con Architect
Pide el diseño técnico del cambio a partir de la propuesta y las specs aprobadas. En GitHub Copilot Chat de VS Code. Selecciona Architect.

Prompt
```
Trabaja en la raíz de ai-labs.
Identifica el componente del Issue: auth/, api/ o web/.
Limita el código y las pruebas al componente elegido; conserva las secciones de los demás componentes en los documentos generales.
Git, MCP y OpenSpec se ejecutan desde la raíz; las pruebas usan el directorio del componente.
Conserva el alcance del Issue dentro de ai-labs y el componente elegido.

Trabaja sobre la rama actual . No crees ni cambies a otra rama.

Trabaja sobre el cambio OpenSpec  ya aprobado.
Lee proposal.md y specs/ antes de proponer cualquier diseño.

Crea o completa:
openspec/changes//design.md

El design debe incluir:
- contexto técnico relevante;
- goals / non-goals;
- contratos protegidos;
- componentes afectados;
- decisiones técnicas y alternativas consideradas;
- estrategia incremental;
- pruebas de caracterización necesarias antes de modificar comportamiento crítico;
- riesgos / trade-offs;
- rollback cuando aplique.

No implementes código funcional.
No rediseñes toda la aplicación.
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 5 de 15

# Crear tasks.md (Tasks)
Checklist de implementación vinculada al Issue. Mantén GitHub como tracking de trabajo comprometido. GATE HUMANO antes de validar.

Ordena el trabajo aprobado en tareas pequeñas y demostrables.

En Copilot con Architect.

- Deriva las tareas del Issue, proposal, specs y design.
- Sitúa la caracterización antes del cambio funcional.
- Revisa que cada tarea tenga una forma de comprobarse.
### Resultado esperado

- tasks.md debe ser coherente con los artefactos y conservar pendientes las tareas que todavía no se ejecutaron.
### Preparar el checklist de tareas
Descompone el diseño aprobado en tareas pequeñas que permitan ejecutar y revisar el cambio. En GitHub Copilot Chat de VS Code. Selecciona Architect.

Prompt
```
Trabaja en la raíz de ai-labs.
Identifica el componente del Issue: auth/, api/ o web/.
Limita el código y las pruebas al componente elegido; conserva las secciones de los demás componentes en los documentos generales.
Git, MCP y OpenSpec se ejecutan desde la raíz; las pruebas usan el directorio del componente.
Conserva el alcance del Issue dentro de ai-labs y el componente elegido.

Continúa sobre la rama actual . No crees ni cambies de rama.

Usa proposal.md, specs/ y design.md ya aprobados del cambio OpenSpec .

Genera o completa:
openspec/changes//tasks.md

Las tareas deben:
- estar dentro del alcance del GitHub Issue;
- ser pequeñas y verificables;
- comenzar por las pruebas de caracterización necesarias antes del cambio funcional;
- incluir la implementación incremental;
- incluir pruebas/validaciones relevantes;
- evitar trabajo secundario no aprobado.

El GitHub Issue sigue siendo la unidad de trabajo del producto. tasks.md es el checklist de implementación de este cambio OpenSpec.

No implementes todavía el cambio funcional.
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 6 de 15

# Validar (Validate) antes de tocar código
Ejecuta openspec validate y revisiones humanas de los artefactos (Specify/Plan/Tasks). Recién después sigue el baseline de characterization tests en S4.

Comprueba los artefactos y su coherencia antes de tocar el comportamiento de ai-labs.

En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

- Identifica el nombre real del cambio.
- Consulta status y ejecuta validate.
- Revisa proposal, specs, design y tasks con el participante.
### Resultado esperado

- Conserva la validación y los gates humanos de los artefactos. Las pruebas del baseline se realizan después, en S4.
### Consultar los cambios de OpenSpec
Lista los cambios activos que OpenSpec reconoce en este repositorio. Sirve para identificar el nombre del cambio que usarás en status y validate. En la raíz de tu repositorio local, después de inicializar OpenSpec.

Comando
```
openspec list
```

### Revisar el estado de los artefactos
Consulta qué artefactos del cambio están disponibles y cuáles siguen pendientes según el workflow de OpenSpec. En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

Comando
```
openspec status --change 
```

### Validar los artefactos del cambio
Comprueba las reglas de estructura y contenido que OpenSpec aplica a las especificaciones del cambio seleccionado. En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

Comando
```
openspec validate 
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 7 de 15

# Copiar los Custom Agents al workspace
Descarga los cuatro templates de Agents del portal y guárdalos en ai-labs/.github/agents/, dentro de tu carpeta con matrícula y nombre. Si ya tienes una copia externa de los materiales, puedes copiarlos desde templates/agents/. No necesitas clonar bcp-ai-labs. Conserva los archivos existentes; en S4 paso 0 comprueba su presencia en esa misma raíz.

Hace disponibles los roles persistentes del taller en el workspace de VS Code.

En ai-labs/.

- Descarga los cuatro templates de Agents desde los enlaces de la guía del portal. Si ya tienes una copia externa de los materiales, puedes usar templates/agents/ de esa copia.
- Guarda pm-po.agent.md, discovery.agent.md, architect.agent.md y developer.agent.md en .github/agents/ del workspace, conservando archivos existentes.
- Refresca VS Code y comprueba que puedes seleccionar los perfiles.
### Resultado esperado

- Debe existir ai-labs/.github/agents/ con los cuatro perfiles. La preparación del módulo SDD comprueba su presencia en esa misma raíz.Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 8 de 15

# Probar los límites de un agente aislado
Selecciona un solo Custom Agent (Discovery, PM/PO, Architect o Developer) sin usar tools y verifica que explique su responsabilidad y a qué rol debe pasar lo que no le corresponde.

Prueba las responsabilidades de cada agente de forma aislada antes de usar sus tools.

En Copilot Chat, seleccionando un solo Custom Agent por prueba.

- Abre el prompt correspondiente al rol elegido.
- Ejecútalo sin lecturas de archivos ni tools, como indica el texto.
- Revisa el límite que explica el agente y el rol al que deriva lo que no le corresponde.
### Resultado esperado

- Debes poder justificar qué decide cada rol y comprobar que respeta el límite solicitado en la prueba.
### Probar los límites de Discovery
Comprueba que Discovery reconoce su límite antes de darle acceso al producto. En GitHub Copilot Chat de VS Code. Selecciona Discovery.

Prompt
```
Esta es únicamente una prueba de los límites de tu rol.
No leas archivos, no busques en el workspace y no uses MCP ni ninguna otra tool.

Supón que durante un análisis encuentras un problema importante en ai-labs.
¿Puedes corregirlo directamente?
Explica qué deberías hacer según tu responsabilidad antes de que alguien modifique código.
```

### Probar los límites de PM/PO
Comprueba que PM/PO separa la decisión de producto del diseño y la implementación técnica. En GitHub Copilot Chat de VS Code. Selecciona PM/PO.

Prompt
```
Esta es únicamente una prueba de los límites de tu rol.
No leas archivos y no uses ninguna tool.

Supón que se detectó deuda en la capa de persistencia de ai-labs.
¿Debes decidir y ejecutar tú mismo el refactor técnico?
Explica qué te corresponde hacer y a qué rol debería pasar la decisión técnica.
```

### Probar los límites de Architect
Comprueba que Architect define decisiones técnicas sin asumir la implementación del cambio. En GitHub Copilot Chat de VS Code. Selecciona Architect.

Prompt
```
Esta es únicamente una prueba de los límites de tu rol.
No leas archivos y no uses ninguna tool.

Supón que recibes un hallazgo técnico ya confirmado.
¿Debes implementar directamente el cambio en código?
Explica cuál es tu responsabilidad y cuándo debe intervenir Developer.
```

### Probar los límites de Developer
Comprueba que Developer pide trabajo aprobado antes de modificar el producto. En GitHub Copilot Chat de VS Code. Selecciona Developer.

Prompt
```
Esta es únicamente una prueba de los límites de tu rol.
No leas archivos y no uses ninguna tool.

Te piden mejorar todo ai-labs sin issue, spec ni alcance aprobado.
¿Debes empezar a modificar código?
Explica qué información necesitas antes de implementar.
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 9 de 15

# Verificar MCP oficial + Projects habilitado
Confirma que github-official expone tools de Projects y que puedes leer Projects vía MCP.

Comprueba que VS Code puede consultar el backend y Projects a través del MCP oficial.

En VS Code con Agent estándar y github-official.

- Revisa .vscode/mcp.json y el toolset projects.
- Comprueba la conexión y las tools disponibles en Configure Tools.
- Ejecuta las consultas de lectura y conserva la tool y el resultado.
### Resultado esperado

- La evidencia debe mostrar una lectura real de Projects y del repositorio mediante MCP. Si hay un problema de permisos, resuélvelo antes de operar el Project.
### Comprobar Projects mediante MCP
Verifica que el MCP oficial puede consultar Projects con tu identidad y permisos actuales. En GitHub Copilot Chat de VS Code. Selecciona Agent estándar.

Prompt
```
Usando exclusivamente github-official, lista los GitHub Projects accesibles para mi usuario.

No uses terminal, GitHub CLI, web ni otras herramientas.
Indica qué tool MCP utilizaste.
```

### Consultar ai-labs mediante MCP
Verifica una lectura del repositorio de ai-labs mediante GitHub MCP. En GitHub Copilot Chat de VS Code. Selecciona Agent estándar.

Prompt
```
Usando exclusivamente github-official, consulta información de /ai-labs y dime qué tool MCP utilizaste.
No uses terminal ni GitHub CLI para obtener la información de GitHub.
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 10 de 15

# Completar backlog (sin inventar trabajo)
Discovery revalida HALLAZGOS.md y convierte hallazgos revisados en issues reales y verificables en el repo correcto.

Completa el backlog con hallazgos revisados y trazables, aprovechando los issues de los días anteriores.

Discovery analiza; PM/PO crea o incorpora trabajo aprobado.

- Revalida HALLAZGOS.md contra código, contratos y pruebas actuales.
- Clasifica humanamente los hallazgos.
- Reutiliza issues existentes; crea los que falten en el repositorio correcto y agrégalos al Project backlog-ai-labs.
### Resultado esperado

- Cada Issue debe tener evidencia, aceptación verificable e Id H-AUTH-NN, H-API-NN o H-WEB-NN. El Project debe conservar esa trazabilidad y evitar duplicados.
### Revalidar los hallazgos de ai-labs
Revalida los hallazgos de ai-labs contra su estado actual para construir backlog con evidencia. En GitHub Copilot Chat de VS Code. Selecciona Discovery.

Prompt
```
Analiza ai-labs sin modificar archivos. Identifica el componente elegido
(auth/, api/ o web/) y limita los hallazgos a ese componente.
Para esta conversación el componente es auth/.

Parte de lo que ya existe: HALLAZGOS.md (Dia 1) y
los issues del Project backlog-ai-labs. Re-verifica cada hallazgo "Pendiente"
contra el codigo actual e indica si ya tiene issue (campo Hallazgo origen).
Despues comprende estructura, contratos (docs/ENDPOINTS.md) y pruebas
existentes (docs/TESTING.md).
Después presenta como máximo 5 hallazgos candidatos.

Para cada hallazgo incluye:
- evidencia concreta;
- por qué importa;
- prioridad propuesta;
- contrato funcional que podría verse afectado;
- cómo lo validarías antes de cambiarlo.

No inventes problemas si no encuentras evidencia.
No implementes soluciones.
```

### Crear issues desde hallazgos confirmados
Convierte únicamente hallazgos aprobados en issues trazables en su repositorio correcto. En GitHub Copilot Chat de VS Code. Selecciona PM/PO.

Prompt
```
Usando exclusivamente github-official, convierte estos hallazgos CONFIRMADOS en issues.

Reglas:
- cada issue debe vivir en el repositorio al que pertenece la evidencia;
- no dupliques: si el hallazgo ya tiene issue en el Project backlog-ai-labs, reutilízalo;
- incluye el Id H-AUTH-NN, H-API-NN o H-WEB-NN del hallazgo de origen y completa el campo Hallazgo origen;
- no inventes nuevos hallazgos;
- incluye problema, evidencia, impacto y criterio verificable;
- antes de crear, muéstrame el repositorio destino y el título propuesto.
```

### Agregar los issues aprobados al Project backlog-ai-labs
Añade al Project backlog-ai-labs los issues que ya aprobaste para coordinarlos desde el producto. En GitHub Copilot Chat de VS Code. Selecciona PM/PO.

Prompt
```
Usando exclusivamente las tools de Projects de github-official, agrega al Project backlog-ai-labs los issues que acabamos de aprobar.
No cambies su repositorio de origen.
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 11 de 15

# De single-agent a routing
Mapea cada rol a un tipo de trabajo: producto/alcance → PM/PO, hallazgo → Discovery, diseño → Architect, implementación → Developer. Prepara el routing explícito de S4.

Define a qué rol se entrega cada tipo de trabajo y qué necesita recibir para empezar.

En Copilot, eligiendo explícitamente el Agent adecuado.

- Producto y alcance se dirigen a PM/PO.
- Hallazgos se dirigen a Discovery; diseño, a Architect.
- Implementación se dirige a Developer después de las aprobaciones.
### Resultado esperado

- Debes explicar el motivo de cada traspaso y sus entradas. El laboratorio usa selección explícita de roles; no pide construir un router autónomo.Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S4 · Paso 12 de 15

# Confirmar el routing del Issue
Verifica que proposal/specs/design/tasks ya pasaron por PM/PO y Architect antes de que Developer implemente.

Confirma que el trabajo llega a Developer con el alcance y el plan aprobados.

En el Issue, el cambio OpenSpec y la rama de ai-labs.

- Revisa el vínculo entre Issue, proposal, specs, design y tasks.
- Confirma la revisión de PM/PO y Architect.
- Valida el cambio antes de comenzar las tareas de caracterización.
### Resultado esperado

- Debe existir una cadena de decisiones revisable y un plan aprobado para el mismo Issue. La validación de OpenSpec se acompaña de la revisión humana.
### Validar los artefactos del cambio
Comprueba las reglas de estructura y contenido que OpenSpec aplica a las especificaciones del cambio seleccionado. En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

Comando
```
openspec validate 
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S4 · Paso 13 de 15

# Proteger baseline (characterization)
Asegura que el comportamiento actual quede cubierto antes de implementar.

Obtiene una línea base de comportamiento que permita detectar regresiones durante la implementación.

En Copilot con Developer en ai-labs; las pruebas se ejecutan con cwd del componente elegido y Maven solo corresponde a auth/.

- Revisa las pruebas ya documentadas.
- Añade solo la caracterización que falte para el alcance aprobado.
- Ejecuta las pruebas, registra sus resultados y actualiza únicamente las tareas verificadas.
### Resultado esperado

- Conserva el comando, el resultado y el comportamiento protegido por cada prueba. El diff de esta etapa debe limitarse a las pruebas necesarias y tasks.md.
### Caracterizar el comportamiento existente
Protege el comportamiento existente de ai-labs antes de implementar el cambio funcional. En GitHub Copilot Chat de VS Code. Selecciona Developer.

Prompt
```
Trabaja en la raíz de ai-labs.
Identifica el componente del Issue: auth/, api/ o web/.
Limita el código y las pruebas al componente elegido; conserva las secciones de los demás componentes en los documentos generales.
Git, MCP y OpenSpec se ejecutan desde la raíz; las pruebas usan el directorio del componente.
Conserva el alcance del Issue dentro de ai-labs y el componente elegido.

Trabaja sobre la rama actual vinculada al GitHub Issue. No crees ni cambies de rama.

Lee el GitHub Issue y el cambio OpenSpec  completo:
- proposal.md;
- specs/;
- design.md;
- tasks.md.

Todavía no implementes el cambio funcional.

Ejecuta únicamente las tareas de tasks.md relacionadas con caracterización y protección del comportamiento existente.

Antes de crear pruebas nuevas, revisa docs/TESTING.md (Dia 1): reutiliza las
que ya protegen el comportamiento y agrega solo las que falten.

Crea las pruebas de caracterización necesarias y ejecútalas.

Reglas:
- no corrijas todavía el problema objeto del Issue;
- no cambies contratos HTTP;
- no amplíes cobertura fuera del scope;
- explica qué requisito o comportamiento protege cada prueba;
- registra el comando ejecutado y su resultado;
- actualiza en tasks.md únicamente las tareas de caracterización realmente completadas;
- si una prueba demuestra que proposal, specs, design o tasks eran incorrectos, detente y solicita revisión.
```

### Ejecutar las pruebas del componente elegido
Ejemplo para auth/: ejecuta Maven con cwd auth/. Para api/ o web/, usa el comando real de su README y docs/TESTING.md desde ese componente. Desde la raíz de ai-labs para el ejemplo auth/. Para otros componentes, ejecuta su suite con cwd api/ o web/.

Comando
```
(cd auth && mvn test)
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S4 · Paso 14 de 15

# Aplicar e implementar incrementalmente
Usa OpenSpec apply, implementa, ejecuta tests y evidencia.

Implementa el Issue aprobado con OpenSpec apply y evidencia incremental.

En Copilot con Developer, sobre la misma rama.

- Lee los artefactos aprobados y el baseline.
- Ejecuta las tareas funcionales pendientes en cambios pequeños.
- Prueba los cambios y actualiza el checklist cuando exista evidencia.
### Resultado esperado

- El diff debe permanecer dentro del Issue, las pruebas relevantes deben tener resultados registrados y cada check debe corresponder a trabajo demostrado.
### Implementar las tareas aprobadas
Ejecuta el cambio aprobado usando OpenSpec apply y el checklist de tareas, con la caracterización como red de seguridad. En GitHub Copilot Chat de VS Code. Selecciona Developer.

Prompt
```
Trabaja en la raíz de ai-labs.
Identifica el componente del Issue: auth/, api/ o web/.
Limita el código y las pruebas al componente elegido; conserva las secciones de los demás componentes en los documentos generales.
Git, MCP y OpenSpec se ejecutan desde la raíz; las pruebas usan el directorio del componente.
Conserva el alcance del Issue dentro de ai-labs y el componente elegido.

Trabaja sobre la rama actual vinculada al GitHub Issue. No crees ni cambies de rama.

Implementa el GitHub Issue seleccionado utilizando el cambio OpenSpec  como definición y plan aprobados.

Fuentes de verdad:
1. GitHub Issue aprobado;
2. openspec/changes//proposal.md;
3. openspec/changes//specs/;
4. openspec/changes//design.md;
5. openspec/changes//tasks.md;
6. pruebas de caracterización existentes y su baseline.

Usa el workflow OpenSpec apply disponible para GitHub Copilot.

Reglas:
- implementa siguiendo las tareas pendientes de tasks.md;
- marca una tarea como completada solo cuando exista evidencia de que terminó;
- no amplíes el scope fuera del Issue y OpenSpec;
- no cambies contratos fuera del alcance;
- no resuelvas hallazgos secundarios;
- no desactives tests ni controles;
- realiza cambios pequeños;
- ejecuta las pruebas relevantes después de cada cambio significativo;
- registra comandos y resultados;
- detente si implementación, spec, design y tasks entran en conflicto.
```
Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S4 · Paso 15 de 15

# Evaluator + DoD + PR
Ejecuta Definition of Done, abre PR con Closes #N y revisa checks. GATE HUMANO de cierre antes de integrar a main.

Prepara una revisión independiente y decide el cierre usando evidencia del cambio.

En Copilot con Developer, GitHub y revisión del participante.

- Valida los artefactos y revisa el diff y las tareas.
- Prepara el PR de la rama del Issue hacia main con Closes #N y evidencia real.
- Evalúa DoD, revisa los checks y toma la decisión humana antes de integrar.
- Después de integrar el PR y aceptar la DoD, archiva el cambio OpenSpec según el workflow instalado. Revisa las specs canónicas en openspec/specs/ y conserva la propuesta archivada. Versiona y revisa ese cierre antes de integrarlo a main.
- Actualiza main local desde el remoto, ejecuta las pruebas reales del componente y comprueba un árbol limpio. Solo entonces crea la rama local checkpoint/day3 desde main. Si ya existe, compruébala sin sobrescribirla.
- Revisa en Git los artefactos de checkpoint/day3, las specs canónicas y los Agents/Skills. Conserva los resultados reales de las pruebas, CI y la aprobación humana; el preparador de entrada no certifica el cierre.
### Resultado esperado

- El PR debe permitir reconstruir Issue → artefactos → pruebas → implementación. Cierra solo los criterios demostrados y registra los que tengan falta de evidencia o bloqueos.
- Revisa en Git los artefactos de checkpoint/day3, las specs canónicas y los Agents/Skills. Conserva los resultados reales de las pruebas, CI y la aprobación humana; el preparador de entrada no certifica el cierre.
### Validar los artefactos del cambio
Comprueba las reglas de estructura y contenido que OpenSpec aplica a las especificaciones del cambio seleccionado. En la raíz de tu ai-labs local, donde están auth/, api/ y web/.

Comando
```
openspec validate 
```

### Preparar el contenido del PR
Prepara un Pull Request que un revisor pueda evaluar con la evidencia del cambio. En GitHub Copilot Chat de VS Code. Selecciona Developer.

Prompt
```
Trabaja en la raíz de ai-labs.
Identifica el componente del Issue: auth/, api/ o web/.
Limita el código y las pruebas al componente elegido; conserva las secciones de los demás componentes en los documentos generales.
Git, MCP y OpenSpec se ejecutan desde la raíz; las pruebas usan el directorio del componente.
Conserva el alcance del Issue dentro de ai-labs y el componente elegido.

Prepara el Pull Request final del GitHub Issue desde la rama actual  hacia main.

Usa únicamente evidencia existente en:
- el GitHub Issue;
- openspec/changes//proposal.md;
- openspec/changes//specs/;
- openspec/changes//design.md;
- openspec/changes//tasks.md;
- diff acumulado;
- pruebas ejecutadas.

Antes de preparar el PR:
- verifica que estás trabajando con ;
- revisa que tasks.md refleje el trabajo realmente completado;
- revisa el diff acumulado;
- confirma que las pruebas relevantes tienen evidencia.

Prepara:
- título;
- descripción;
- Issue relacionado;
- cambio OpenSpec relacionado;
- estado de tasks.md;
- comportamiento protegido;
- cambios realizados;
- pruebas ejecutadas y resultados;
- trade-offs;
- riesgos residuales;
- rollback;
- trabajo fuera de alcance.

No crees ramas adicionales.
No modifiques el código en esta etapa.
```

### Evaluar la Definition of Done
Evalúa la Definition of Done con evidencia existente para decidir si el cambio puede cerrarse. En GitHub Copilot Chat de VS Code. Selecciona Developer.

Prompt
```
Trabaja en la raíz de ai-labs.
Identifica el componente del Issue: auth/, api/ o web/.
Limita el código y las pruebas al componente elegido; conserva las secciones de los demás componentes en los documentos generales.
Git, MCP y OpenSpec se ejecutan desde la raíz; las pruebas usan el directorio del componente.
Evalúa el Issue de ai-labs y su componente elegido.

Usa el Skill reqflow-definition-of-done para evaluar el cambio actual.

Evalúa únicamente con evidencia existente en:
- el GitHub Issue;
- el Pull Request final;
- openspec/changes//proposal.md;
- openspec/changes//specs/;
- openspec/changes//design.md;
- openspec/changes//tasks.md;
- pruebas ejecutadas;
- checks disponibles en GitHub.

Para cada criterio clasifica el resultado como:
- CUMPLIDO;
- PENDIENTE DE OTRO GATE;
- NO APLICA AL ALCANCE;
- FALTA EVIDENCIA;
- BLOQUEADO.

No declares un criterio como cumplido si no existe evidencia verificable.
No modifiques código ni archivos.
Devuélveme una tabla con:
criterio | estado | evidencia | observación
```
Paso completado

AnteriorMarcar pendienteFinalizar laboratorio
