**23 de 23** pasos completados

100%xAvance cargado de tu cuenta.

Pasos del laboratorioSkills, Templates y MCP

Generar token MCPVer un pasoCompletado

S1 · Paso 1 de 23

# Crear estructura del Skill
    Tiempo estimado: 5 minutos. Crea el Skill en la ruta estandar `.github/skills/` de `ai-labs`.   
```
mkdir -p .github/skills/feature-intake-spec-checklist/examples
```
 
```
touch .github/skills/feature-intake-spec-checklist/SKILL.md
```
 
```
touch .github/skills/feature-intake-spec-checklist/examples/input.sample.md
```
 
```
touch .github/skills/feature-intake-spec-checklist/examples/output.sample.md
```
  **Salida esperada:** En Bash, los comandos no muestran mensajes. Crean la carpeta y los tres archivos inicialmente vacíos; la estructura resultante es:

text
```
.github/
└── skills/
    └── feature-intake-spec-checklist/
        ├── SKILL.md
        └── examples/
            ├── input.sample.md
            └── output.sample.md
```
 Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S1 · Paso 2 de 23

# Completar el contrato
   Tiempo estimado: 30-40 minutos. Abre el `SKILL.md` vacío que creaste en el paso anterior y pega la plantilla completa. Completa los campos que la plantilla deje pendientes para tu caso; no contiene marcadores [EDITAR].   Texto
```
---
name: feature-intake-spec-checklist
description: Estandariza la definición de funcionalidades antes de la implementación generando un paquete mínimo trazable que cubra alcance, decisiones, riesgos, criterios de aceptación y planes de validación.
---

# Skill: Feature Intake -> Spec Checklist

## 1) Metadata
- **Skill ID:** feature-intake-spec-checklist
- **Version:** 0.1.0
- **Purpose:** Estandarizar la definición de funcionalidades antes de la implementación generando un paquete mínimo trazable que cubra alcance, decisiones, riesgos, aceptación y validación.
- **Audience (roles):** Chapter/PO, Tech Lead, Backend, Frontend, QA, Cyber
- **When to use:** Antes de crear tareas de implementación o abrir un PR significativo.
- **When NOT to use:** Incidentes P1 de producción, cambios triviales como typos o tareas sin impacto funcional.
- **Sensitive inputs:** No incluyas datos reales de clientes, credenciales, secretos, tokens ni URLs internas no autorizadas.
- **Expected output:** Markdown estructurado mediante la sección Output a continuación.

## 2) Inputs
Proporciona la información en este formato:

- **Business context (brief):**
- **Feature request / user story:**
- **Expected impact (metric or outcome):**
- **Scope (in/out):**
- **Known technical constraints:** (stack, standards, performance, availability)
- **Known risks:** (security, compliance, stability)
- **Dependencies:** (services, teams, data)
- **Team Definition of Done (DoD):** (if available)

## 3) Output
Devuelve **solo** un documento Markdown con estas secciones y bullets:

1. **Summary**
2. **Scope**
    - Dentro del alcance
    - Fuera del alcance
3. **Supuestos**
4. **Decisiones técnicas por tomar (pendientes o resueltas)**
5. **Riesgos y mitigaciones**
6. **Criterios de aceptación (medibles)**
7. **Plan de validación**
    - Pruebas unitarias
    - Pruebas funcionales
    - Seguridad (comprobaciones mínimas)
    - Evidencia requerida (qué adjuntar)
8. **Tareas sugeridas por rol**
    - Chapter/PO
    - Tech Lead
    - Backend
    - Frontend
    - QA
    - Cyber
9. **Preguntas abiertas**

## 4) Constraints
- No inventes requisitos: si falta información, inclúyela bajo **Preguntas abiertas**.
- No propongas herramientas fuera del stack permitido.
- No incluyas datos sensibles ni secretos.
- Los criterios de aceptación deben ser verificables; no escribas “mejorar el rendimiento” sin una métrica.
- El plan de validación debe incluir al menos un elemento de evidencia concreto, como salida de pruebas, un checklist o un archivo actualizado.
- Mantén la salida en un máximo de 1-2 páginas para que siga siendo usable.

## 5) Validation Rules
La salida es válida si:
- Incluye todas las secciones definidas en Output.
- Tiene al menos 3 criterios de aceptación medibles.
- Tiene al menos 3 tareas para cada rol central: Tech Lead, Backend y QA, o explica por qué un rol no aplica.
- Incluye al menos 2 riesgos con mitigaciones.
- No contiene datos sensibles ni secretos.
- No contiene supuestos no declarados.

## 6) Evidence
Adjunta o referencia estos elementos en el PR o entrega:
- `SKILL.md` versionado.
- `examples/input.sample.md`.
- `examples/output.sample.md`.
- Tag de versión para el Skill, como `skill-feature-intake-v0.1.0`.
```
   **Criterio de salida:** otro rol debe poder leer el archivo y saber que activa el Skill, que informacion recibe, que devuelve, que limites respeta y como se valida.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S1 · Paso 3 de 23

# Crear entrada
   Tiempo estimado: 5-10 minutos. Pega el caso de ejemplo en `examples/input.sample.md`; puedes adaptar contexto, impacto o dependencias, conservando los ocho encabezados.   Texto
```
## Business context (brief)
Reduce complaints caused by duplicate transfers.

## Feature request / user story
As a user, I want to confirm a transfer before sending it
so that I can avoid duplicates.

## Expected impact
Reduce duplicate-transfer complaints by 20% in one month.

## Scope (in/out)
In: pre-send confirmation, summary message, data validation.
Out: infrastructure changes and a complete UI redesign.

## Known technical constraints
Existing REST API, web frontend, standardized logging.

## Known risks
Sensitive data exposure in logs; amount-validation errors.

## Dependencies
Accounts service and transfers service.

## Team Definition of Done (DoD)
Unit tests, brief documentation, and reviewed PR.
```
   **Criterio de salida:** la entrada es suficientemente concreta para generar una especificacion sin inventar requisitos; lo no confirmado queda como pregunta abierta.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S1 · Paso 4 de 23

# Crear salida
   Tiempo estimado: 10-15 minutos. Genera `examples/output.sample.md` a partir de la entrada; puedes cambiar decisiones, riesgos o tareas pero no elimines secciones.   Texto
```
# Feature Intake -> Spec Checklist

## 1. Summary
Add a pre-send transfer confirmation with a concise summary
and validation of transfer data. Target: 20% reduction in
duplicate-transfer complaints in one month.

## 6. Acceptance criteria (measurable)
- 95%+ of valid attempts show confirmation before submission.
- Invalid data blocks submission with a validation message.
- Duplicate complaints drop 20% within one month.
- No sensitive values appear in confirmation event logs.

## 9. Open questions
- What baseline measures the 20% reduction?
- Which API version owns the confirmation contract?
```
   **Criterio de salida:** documento Markdown de 1-2 paginas, accionable, sin decisiones no sustentadas por la entrada o una decision humana.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S1 · Paso 5 de 23

# Demostrar y versionar el Skill
   Tiempo estimado: 15-20 minutos. Demuestra que el Skill es descubrible y ejecutable antes de versionarlo.   **1. Listar los skills configurados:**   
```
find .github/skills -maxdepth 2 -type f
```
   **Salida esperada:** el listado muestra `feature-intake-spec-checklist/SKILL.md` y sus dos ejemplos; esto confirma que el Skill esta en la ruta que Copilot descubre automaticamente en el repositorio.   **2. Prompt para ejecutar el Skill (Copilot Chat):**   Texto
```
Actua como el Skill feature-intake-spec-checklist
(.github/skills/feature-intake-spec-checklist/SKILL.md).
Usa como entrada el contenido de examples/input.sample.md y genera
UNICAMENTE el documento Output definido en el contrato del Skill.
```
   **Salida esperada:** Copilot Chat responde con un unico documento Markdown con las nueve secciones del contrato (Summary, Scope, Assumptions ... Open questions), coherente con `examples/output.sample.md` y sin inventar datos fuera de la entrada.   **3. Commit y tag:**   
```
git add .github/skills/feature-intake-spec-checklist
```
 
```
git commit -m "Add basic skill: feature intake to spec checklist (v0.1.0)"
```
 
```
git tag skill-feature-intake-v0.1.0
```
   **Criterio de salida:** el Skill es descubrible en `.github/skills/`, produce el documento esperado al invocarlo desde Copilot Chat y queda versionado con commit y tag.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S1 · Paso 6 de 23

# Aplicar el Skill a la HU-01
   `Tiempo estimado: 15-20 minutos. HU-01.md` no se copia: se genera desde el `HALLAZGOS.md` de tu `ai-labs` del Dia 1 (filas "Pendiente" sobre el token).   Texto
```
CONTEXTO
Estás en la raíz de ai-labs. HALLAZGOS.md es la matriz de hallazgos del Día 1.

OBJETIVO
Generar HU-01.md en la raíz de ai-labs a partir de las filas "Pendiente"
de HALLAZGOS.md relacionadas con el token de autenticacion.

RESTRICCIONES
No inventes hallazgos que no esten en HALLAZGOS.md. No incluyas valores de
tokens, secretos ni credenciales.

CRITERIOS DE ACEPTACION
La evidencia identifica el componente y sus IDs H-AUTH-NN, H-API-NN o H-WEB-NN.
HU-01.md tiene las secciones Origen, Contexto, Ajustes necesarios, Criterios de
aceptacion y Evidencia esperada. Origen lista los Id (H-AUTH-NN, H-API-NN o H-WEB-NN) y la evidencia
archivo:linea de cada hallazgo usado. Cada criterio de aceptacion es
verificable con una prueba.

FORMATO DE RESPUESTA
Solo el archivo HU-01.md.
```
   Solo si tu `HALLAZGOS.md` no tiene hallazgos de token en estado "Pendiente", crea `HU-01.md` y pega esta version de referencia:   Texto
```
# HU-01 - Token firmado con expiracion y claims minimos

## Veredicto
**Usable con ajustes.** La historia conecta seguridad, configuracion, testing y evidencia.

## Contexto
El servicio de autenticacion expone `POST /auth/login` y devuelve `token`, `expiresIn` y `user`. La implementacion usa firma HMAC y lee `AUTH_TOKEN_SECRET`.

## Ajustes necesarios
- Exigir los claims `sub`, `client`, `iat` y `exp`.
- Obtener `client` desde la solicitud, validarlo y reflejarlo en el token.
- Comprobar que `expiresIn` coincide con `exp - now` usando una tolerancia documentada.
- Eliminar el secreto por defecto fuera del laboratorio o documentarlo como exclusivo de laboratorio.
- Evitar logs del token y del secreto.
- Mantener como decision tecnica si se conserva HMAC o se adopta una libreria JWT.

## Criterios de aceptacion
- Un token valido contiene `sub`, `client`, `iat` y `exp`.
- `expiresIn` es coherente con `exp - now` dentro de la tolerancia definida.
- Login valido, credenciales invalidas y token expirado tienen pruebas.
- No se registran tokens, secretos ni valores sensibles.
- La decision sobre HMAC frente a una libreria JWT queda documentada.

## Evidencia esperada
- Documento generado por los Skills a partir de este archivo.
- Pruebas de claims, expiracion y errores de autenticacion.
- Configuracion documentada de `AUTH_TOKEN_SECRET`.
- Evidencia de logs redactados.
```
   **Comprobacion:** confirma que el archivo existe y que Copilot Chat puede leerlo desde la raiz del repositorio.   
```
test -f HU-01.md && cat HU-01.md
```
   **Prueba:** Genera tu Prompt para usar este skill con el archivo creado (HU-01.md). Puedes tambien usar el siguiente Prompt:   Texto
```
Actua como el Skill feature-intake-spec-checklist
(.github/skills/feature-intake-spec-checklist/SKILL.md).

Desde la raíz de ai-labs, lee HU-01.md y usa el archivo como unica entrada.
Genera UNICAMENTE el documento Output definido en el contrato del Skill,
con sus nueve secciones: Summary, Scope (in/out), Assumptions,
Technical decisions to make, Risks and mitigations, Acceptance criteria,
Validation plan, Suggested tasks by role y Open questions.

No inventes requisitos. Marca como pregunta abierta toda decision que la HU
no confirme. No incluyas valores de tokens, secretos ni credenciales.
```
   **Revisar el resultado:** verifica que la respuesta cubra los claims `sub`, `client`, `iat` y `exp`; la relacion entre `expiresIn` y `exp`; la configuracion segura de `AUTH_TOKEN_SECRET`; ausencia de logs sensibles; pruebas de token, expiracion y claims; y tareas para Tech Lead, Backend y QA. La decision HMAC frente a una libreria JWT debe quedar como una decision tecnica o pregunta abierta, no como un hecho inventado.   **Criterio de salida:** `HU-01.md` esta versionado en la raiz, el Skill lee el archivo como entrada y produce un documento trazable, sin secretos, con criterios de aceptacion verificables y preguntas abiertas donde falte confirmacion.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S1 · Paso 7 de 23

# Versionar el laboratorio
   Tiempo estimado: 5 minutos. Sube todo lo trabajado en S1 (Skill y HU-01.md) y marca el laboratorio con un tag.  Línea de comandos · bashBásicoAvanzado
```
git add -A
```

```
git commit -m "lab02-s1: skill basico feature-intake-spec-checklist + HU-01"
```

```
git push origin HEAD
```

```
git push origin skill-feature-intake-v0.1.0
```

```
git tag lab02-s1
```

```
git push origin lab02-s1
```
  **Criterio de salida:** el repositorio remoto contiene `.github/skills/feature-intake-spec-checklist/`, `HU-01.md` y el tag `lab02-s1` apunta al commit final del laboratorio (ademas de `skill-feature-intake-v0.1.0`).  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 8 de 23

# Verificar prerrequisitos: workshops y Skill de S1
  [Probar comandos y su salida en la terminal web](/dia-02/sandbox.html)

  Tiempo: 5 minutos. Desde `ai-labs/`, confirma que los componentes auth/, api/, web/ y el Skill de S1 existen antes de continuar.   
```
test -d auth && echo "OK: auth"
```
 
```
test -d web && echo "OK: web"
```
 
```
test -d api && echo "OK: api"
```
 
```
test -d .github/skills/feature-intake-spec-checklist && echo "OK: skill de S1"
```
   Si falta alguno de los repos, no clones la plantilla limpia: créalo como repo propio con el paso 1 del README del Dia 1, o parte de la rama `checkpoint/day1`.   **Salida esperada:** los cuatro `test` confirman presencia.  [Probar comandos y su salida en la terminal web](/dia-02/sandbox.html)Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 9 de 23

# Instalar los cinco Skills desde GitHub
**Tiempo:** 5 minutos.

Instala los cinco Skills una sola vez en la raíz de ai-labs. Abre la terminal de VS Code en esa carpeta, junto a .git y AGENTS.md.

FlujoCarpeta de la terminalAutenticación`ai-labs/`Login`ai-labs/`Requisitos`ai-labs/`Ejecuta este único comando desde la raíz de ai-labs. Los Skills se comparten entre auth/, api/ y web/; no los instales dentro de cada componente.

```
npx --yes skills@1.7.4 add NTTData-Academy/bcp-ai-skill-catalog --skill discovery-analysis spec-writing architecture-decision issue-implementation reqflow-definition-of-done -a github-copilot --copy -y
```
Requiere Node.js 22.20 o superior. Si el catálogo es privado, tu cuenta debe tener acceso y Git debe estar autenticado.

- npx --yes skills@1.7.4 descarga y ejecuta esa versión de la CLI Skills de Vercel. --yes evita la confirmación de npx.
- add NTTData-Academy/bcp-ai-skill-catalog toma los Skills de ese repositorio de GitHub.
- --skill limita la instalación a los cinco nombres que siguen.
- -a github-copilot selecciona GitHub Copilot.
- --copy copia los archivos sin enlaces simbólicos, para usarlos en Windows.
- -y acepta las opciones de instalación de Skills sin preguntas interactivas.La instalación es local al repositorio donde ejecutas el comando. **Salida esperada:** allí aparecen los cinco directorios `.agents/skills//`, cada uno con su `SKILL.md`. Conserva el Skill de S1 en `ai-labs/.github/skills/feature-intake-spec-checklist/`.

Conserva las secciones de otros componentes en los documentos compartidos. Usa H-AUTH-NN, H-API-NN o H-WEB-NN para trazar los hallazgos. Modifica solo el código del componente del Issue y ejecuta sus pruebas con cwd en auth/, api/ o web/.

Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 10 de 23

# Reconocer los cinco Skills del ciclo SDLC
**Tiempo:** 5 minutos.

Las instrucciones vienen del repositorio [NTTData-Academy/bcp-ai-skill-catalog en GitHub](https://github.com/NTTData-Academy/bcp-ai-skill-catalog). El comando anterior las copia a tu repositorio. Cada Skill tiene su propio archivo `SKILL.md`; la guía de S2 del portal describe el ejercicio.

En el Explorador de VS Code, abre la carpeta del repositorio donde instalaste los Skills, luego `.agents` → `skills` → el nombre del Skill → `SKILL.md`. Por ejemplo, para autenticación abre `ai-labs/.agents/skills/discovery-analysis/SKILL.md`.

También puedes leer los archivos originales en GitHub con los enlaces de esta tabla. Si el catálogo es privado, inicia sesión con una cuenta que tenga acceso.

Instrucciones originales en GitHubUso en el laboratorio[discovery-analysis](https://github.com/NTTData-Academy/bcp-ai-skill-catalog/blob/main/domains/quality/discovery-analysis/SKILL.md)Investigar hallazgos con evidencia sin cambiar código[spec-writing](https://github.com/NTTData-Academy/bcp-ai-skill-catalog/blob/main/domains/specification/spec-writing/SKILL.md)Especificar el cambio aprobado[architecture-decision](https://github.com/NTTData-Academy/bcp-ai-skill-catalog/blob/main/domains/architecture/architecture-decision/SKILL.md)Evaluar impacto y registrar decisiones técnicas[issue-implementation](https://github.com/NTTData-Academy/bcp-ai-skill-catalog/blob/main/domains/quality/issue-implementation/SKILL.md)Implementar el issue aprobado con pruebas[reqflow-definition-of-done](https://github.com/NTTData-Academy/bcp-ai-skill-catalog/blob/main/domains/review/reqflow-definition-of-done/SKILL.md)Revisar criterios de aceptación y evidencia**Salida esperada:** identificas qué Skill usar en cada etapa y encuentras sus instrucciones tanto en tu repositorio como en el catálogo de origen.

[Guía de S2 del laboratorio](/dia-02/s2_templates/STEP-BY-STEP.html)Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 11 de 23

# Verificar los Skills instalados
**Tiempo:** 5 minutos.

En la misma terminal del repositorio donde ejecutaste la instalación, comprueba los cinco archivos:

Línea de comandos · bash
```
for skill in discovery-analysis spec-writing architecture-decision issue-implementation reqflow-definition-of-done; do
  if test -f ".agents/skills/$skill/SKILL.md"; then
    echo "OK: $skill"
  else
    echo "FALTA: $skill"
  fi
done
```
**Salida esperada:** cinco resultados `OK` y ningún `FALTA` en ai-labs. Si aparece `FALTA`, revisa la carpeta de la terminal y la salida de la instalación. Copilot reconoce `.agents/skills/` y conserva acceso al Skill de S1 en `.github/skills/`.

Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 12 de 23

# Discovery - Encontrar hallazgos y seleccionar un issue candidato
   Tiempo: 10-15 minutos. Usa `discovery-analysis` para analizar el producto ReqFlow (multi-repo) y producir una lista corta de hallazgos con evidencia. No modifiques codigo.   Texto
```
Actua como el Skill discovery-analysis
(.agents/skills/discovery-analysis/SKILL.md).

Contexto: estas en la raíz de ai-labs/, con auth/, api/ y web/.
Investiga solo el componente elegido; HALLAZGOS.md está en la raíz.
Usa sus IDs H-AUTH-NN, H-API-NN o H-WEB-NN. Conserva las secciones de otros componentes.

Objetivo: produce 3-5 hallazgos con evidencia concreta (archivo:linea o comando),
impacto, prioridad propuesta, contrato potencialmente afectado y como validarlo.

Restricciones:
- no modificar codigo;
- no crear issues automaticamente;
- marca todo como CANDIDATO y detente para revision humana.
```
   **Salida esperada:** 3-5 hallazgos con evidencia (Estado: CANDIDATO) listos para convertir en Issue tras gate humano.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 13 de 23

# Spec - Especificar el cambio aprobado
   Tiempo: 10-15 minutos. Usa `spec-writing` para convertir el hallazgo/Issue aprobado en una spec verificable (sin diseno ni implementacion).   Texto
```
Actua como el Skill spec-writing
(.agents/skills/spec-writing/SKILL.md).

Fuente: usa como entrada el hallazgo/Issue aprobado (titulo + evidencia + impacto).
Incluye contratos protegidos de ReqFlow cuando aplique.

Entrega solo la spec en el formato sugerido por el Skill y detente para
revision humana.
```
   **Salida esperada:** spec verificable con alcance, fuera de alcance, criterios de aceptacion y contratos protegidos.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 14 de 23

# Architecture - Decidir estrategia y pruebas a proteger
   Tiempo: 10-15 minutos. Usa `architecture-decision` para evaluar impacto, estrategia incremental y pruebas necesarias antes de implementar.   Texto
```
Actua como el Skill architecture-decision
(.agents/skills/architecture-decision/SKILL.md).

Entrada: spec aprobada.
Salida: impacto, componentes, contratos protegidos, estrategia incremental,
pruebas necesarias, riesgos/trade-offs y decisiones abiertas.

Detente para revision humana antes de implementar.
```
   **Salida esperada:** plan tecnico incremental y testeable (sin reescrituras ni cambios fuera de alcance).  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 15 de 23

# Implementation - Implementar un issue aprobado con evidencia
   Tiempo: 15-20 minutos. Usa `issue-implementation` para guiar la implementacion incremental del Issue aprobado, con pruebas y PR auditable.   Texto
```
Actua como el Skill issue-implementation
(.agents/skills/issue-implementation/SKILL.md).

Precondiciones:
- issue aprobado
- spec aprobada
- impacto/arquitectura aprobada

Implementa el cambio minimo necesario, ejecuta pruebas relevantes y prepara
un PR con evidencia real.
```
   **Salida esperada:** implementacion acotada + evidencia de pruebas/validaciones, lista para PR.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 16 de 23

# Review - Evaluar el cambio con DoD de ReqFlow
   Tiempo: 8-10 minutos. Usa `reqflow-definition-of-done` como evaluator final basado en evidencia.   Texto
```
Actua como el Skill reqflow-definition-of-done
(.agents/skills/reqflow-definition-of-done/SKILL.md).

Evalua el cambio propuesto/implementado para el Issue trabajado en S2.

Para cada criterio responde solo con:
- CUMPLIDO (citar evidencia)
- FALTA EVIDENCIA (decir que falta)
- BLOQUEADO (explicar causa)
- NO APLICA AL ALCANCE (justificar)
- PENDIENTE DE OTRO GATE (indicar cual)

No inventes ejecuciones de CI ni cobertura.
```
   **Salida esperada:** evaluacion DoD con evidencia/citas y una decision explicita de si el cambio puede avanzar a PR.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S2 · Paso 17 de 23

# Versionar el laboratorio
   Tiempo: 5 minutos. Sube todo lo trabajado en S2 (Skills instalados, cambios de HU-01/HU-05, matriz de pruebas y evidencia) y marca el laboratorio con un tag.   Ejecuta dentro del repositorio que modificaste. Elige una sola variante. En Básico, ejecuta una línea y revisa su resultado antes de seguir. Avanzado encadena con && y publica la rama y la etiqueta en un solo git push; se detiene si falla una operación. Revisa los archivos preparados antes de crear el commit.

Línea de comandos · bashBásicoAvanzado
```
git add -A
```

```
git commit -m "lab02-s2: skills catalog GitHub + ciclo SDLC (HU-01, HU-05)"
```

```
git tag lab02-s2
```

```
git push origin HEAD
```

```
git push origin lab02-s2
```
       **Criterio de salida:** el repositorio remoto contiene los 5 Skills instalados, los cambios de HU-01 y HU-05, `SDLC-EVIDENCE.md`, y el tag `lab02-s2` apunta al commit final del laboratorio.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 18 de 23

# Levantar el MCP local
Usa la carpeta con matrícula y nombre creada por curso. El clon auxiliar bcp-ai-lab-day-02 va al lado de ai-labs/, dentro de esa carpeta. No clones bcp-ai-labs ni arranques el MCP desde el código del portal.

Tiempo: 20-30 minutos. Sigue una petición desde Inspector hasta GitHub, comprende el token del servidor y ejecuta el MCP y su cliente de prueba en dos terminales.

## Para qué usamos Inspector
**Inspector permite probar las herramientas del MCP manualmente:** eliges una, completas sus datos y revisas la respuesta. El **servidor MCP** hace la consulta a **GitHub** usando el token de `.env`.

Después de comprobarlo, conectarás **VS Code con Copilot al mismo MCP**. VS Code hará las peticiones directamente; ya no necesitarás Inspector.

## 1.1 Preparar .env en la raíz del Día 2
Los materiales del Día 2 van **al lado de `ai-labs`**. Esta es la ubicación esperada:

text
```
-/
├── ai-labs/                 tu repositorio de ejercicios
│   ├── AGENTS.md
│   ├── auth/
│   ├── api/
│   └── web/
└── bcp-ai-lab-day-02/       materiales del Día 2
    ├── .env
    └── s3_mcp/
```
**Si falta `bcp-ai-lab-day-02`:** en el explorador de archivos, abre `-`, la que contiene `ai-labs`. Abre Git Bash en esa carpeta y ejecuta el bloque completo para clonar y entrar en los materiales:

Línea de comandos · bash
```
git clone https://github.com/NTTData-Academy/bcp-ai-lab-day-02.git
```

```
cd bcp-ai-lab-day-02
```
**Si ya existe:** abre Git Bash directamente en `bcp-ai-lab-day-02` y omite el bloque anterior.

Desde `bcp-ai-lab-day-02`, copia la plantilla de configuración:

```
cp -n .env.example .env
```
`-n` conserva tu `.env` si ya existe. Abre ese archivo en tu editor y completa:

dotenv
```
GITHUB_TOKEN=PEGA_AQUI_TU_TOKEN
GITHUB_OWNER=TU_OWNER
GITHUB_REPO=TU_REPO_DE_PRUEBA
AGENT_RECLAIM_ENABLED=false
```
`OWNER` es el usuario u organización; `REPO`, solo el nombre del repositorio. La última variable desactiva una función del servidor que no usaremos. Si `.env` ya existe, conserva su contenido y agrega estos valores.

Para obtener el token de tu sesión de GitHub CLI, ejecuta en tu terminal local:

```
gh auth token
```
Copia el resultado únicamente a `GITHUB_TOKEN`. Si falta la sesión, usa `gh auth login`. Hazlo fuera de capturas o grabaciones. `.env` está excluido de Git; no lo compartas ni lo incluyas en evidencias. No escribas `$(gh auth token)` dentro del archivo: ahí van valores, no comandos.

## 1.2 Terminal 1: arrancar el MCP
Antes de arrancar, limpia la caché global de npm. Así `npx` descarga las versiones fijadas y no reutiliza una instalación anterior:

```
npm cache clean --force
```
Después, desde la raíz del Día 2, ejecuta:

```
npx -y mcp-proxy@6.7.20 --host 127.0.0.1 --port 8081 --server stream --shell -- npx -y mcp-github-project-manager@2.3.1 --env-file .env
```
`npx` descarga y ejecuta los paquetes. El proxy abre la conexión HTTP y arranca el servidor, que lee `.env`. `--shell` lanza el servidor a través de tu shell; en Windows es necesario porque `npx` se ejecuta como `npx.cmd`. Espera a que indique que escucha en el puerto **8081** y deja esta terminal abierta. No necesitas construir imágenes.

## 1.3 Terminal 2: abrir Inspector
Sin cerrar la anterior, abre otra pestaña de terminal y ejecuta:

```
npx -y @modelcontextprotocol/inspector@2.11.0
```
Abre en el navegador la URL completa que imprime Inspector, normalmente en el puerto **6274**. Incluye una clave local que Inspector genera automáticamente; es distinta del token de GitHub. Deja también esta terminal abierta.

DirecciónDónde se usaURL de Inspector, puerto **6274**Se abre en el navegador para ver la aplicación de prueba.`http://localhost:8081/mcp`Se pega dentro de Inspector para conectar con el MCP de la Terminal 1.
## 1.4 Navegador: conectar y ver las herramientas

- En Inspector pulsa Add Servers → + Add manually.
- Completa Server ID: github-local, Transport: streamable-http y URL: http://localhost:8081/mcp.
- Pulsa Add y activa el interruptor de la tarjeta para conectar.
- Abre Tools y busca discover_tools y manage_issues.Ver las herramientas comprueba la conexión con el MCP. Todavía no comprueba el acceso a GitHub.

## 1.5 Probar la consulta del gráfico

- Selecciona discover_tools, elige domain: issues y pulsa Execute Tool para conocer las acciones disponibles.
- Selecciona manage_issues y completa action: list, el mismo owner/repo de tu .env y status: open. El token no se introduce aquí.
- Pulsa Execute Tool. El MCP consulta GitHub y la respuesta aparece en Inspector.Una lista de issues, incluso vacía, confirma el acceso al repo para esa consulta. Si recibes un error de permisos, revisa el token y el acceso en GitHub. Guarda la petición y su respuesta como evidencia, sin credenciales.

## Continuar con VS Code
Mantén la **Terminal 1** abierta para el Paso 2. Puedes cerrar Inspector con `Ctrl+C` en la **Terminal 2**: el MCP seguirá activo y VS Code se conectará a su misma URL. Cerrar solo la página del navegador no detiene ninguno de los servicios.

## Si algo falla

- No encuentra .env: ejecuta el comando desde la raíz del Día 2 o indica una ruta absoluta después de --env-file.
- Token o repositorio incorrectos: corrige .env y reinicia la Terminal 1. Abre una terminal limpia si antes habías exportado variables GITHUB_*.
- Puerto ocupado: detén la instancia anterior antes de arrancar otra.
- Versión antigua o error al descargar: ejecuta npm cache clean --force, cierra la Terminal 1 y vuelve a arrancar el MCP.
- Inspector no conecta: confirma que el MCP sigue activo, el transporte es streamable-http y la URL termina en /mcp.
- GitHub rechaza la consulta: revisa permisos y scopes. Para Projects puede hacer falta gh auth refresh -s project; después actualiza el token y reinicia el MCP.Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 19 de 23

# Conectar VS Code y descubrir tools
   Tiempo: 15-20 minutos. En la raíz de `ai-labs/` (junto a .git y AGENTS.md) crea `.vscode/mcp.json`, abre Copilot Chat en modo **Agent** estandar y habilita el servidor local.   Texto
```
{
  "servers": {
    "github-local": {
      "type": "http",
      "url": "http://localhost:8081/mcp"
    }
  }
}
```
   En **Configure Tools**, verifica que aparezca `github-local` (o el nombre derivado del servidor) y habilita `discover_tools` y `manage_issues`. Para la primera prueba deshabilita temporalmente las Built-in `agent`, `browser`, `edit`, `execute`, `search`, `todo`, `vscode` y `web`. Mantén `read` habilitada: solo puede procesar resultados MCP grandes almacenados por VS Code, no obtiene datos de GitHub.   Texto
```
Usa exclusivamente la herramienta MCP discover_tools.

Busca que herramienta y que accion permiten listar issues de un repositorio.
No uses terminal, archivos locales, web ni ninguna otra herramienta.
```
   **Salida esperada:** identificar `manage_issues` con `action = list`.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 20 de 23

# Consultar issues y comprobar permisos locales
   Tiempo: 20 minutos. Los repos de laboratorio aun no tienen issues (los del backlog, uno por HU, se crean en el paso 04): primero crea un issue temporal con una escritura controlada y despues léelo. Sustituye `` y `` por el repositorio configurado. Revisa la llamada propuesta antes de autorizar la escritura.   Texto
```
Usa la herramienta MCP manage_issues.

Ejecuta la accion "create" con estos parametros:
owner: 
repo: 
title: MCP local - write permission test
body: Issue temporal creado para validar permisos del laboratorio MCP.

No uses terminal, GitHub CLI, web ni archivos del workspace.
Antes de ejecutar, muestrame la tool MCP y los parametros que vas a enviar.
```
   Ahora que existe al menos un issue, léelo y observa la invocacion MCP y sus parametros como evidencia de que GitHub se consulto mediante el servidor local.   Texto
```
Usa la herramienta MCP manage_issues.

Ejecuta la accion "list" con estos parametros:
owner: 
repo: 
status: open

No uses terminal, GitHub CLI, web, archivos locales ni ninguna otra herramienta.
Resume numero, titulo y estado de cada issue.
```
   **Evidencia esperada:** una llamada equivalente a `Ran Manage Issues` con `action: list`, `owner`, `repo` y `status: open` que devuelve el issue temporal. Luego inicia un chat nuevo y prueba: `Usando el MCP local, consulta los issues abiertos de / y resume numero, titulo y estado.` Compara la seleccion automatica de la tool con la invocacion explicita.   Cierra o elimina el issue temporal. Explica donde se aplica una restriccion: tool expuesta, configuracion del servidor, scope del token, permiso de la cuenta o GitHub. La conclusion es: **tool visible != permiso efectivo**.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 21 de 23

# Conectar GitHub MCP oficial y comparar
   Tiempo: 20-25 minutos. Agrega el servidor remoto oficial al mismo `.vscode/mcp.json`. Completa el flujo de autenticacion soportado por tu organizacion; no incluyas tokens en archivos versionados.   Texto
```
{
  "servers": {
    "github-official": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/"
    },
    "github-official-readonly": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/",
      "headers": {
        "X-MCP-Toolsets": "issues,repos,pull_requests",
        "X-MCP-Readonly": "true"
      }
    }
  }
}
```
   Texto
```
Que tools MCP tienes disponibles en github-official?
No ejecutes ninguna; agrupelas por proposito.

Usando exclusivamente github-official, consulta los issues abiertos de OWNER/REPO y resume numero, titulo 
y estado.
No uses terminal, GitHub CLI, busquedas del workspace ni archivos locales.
```
   Registra que tool oficial resolvio la lectura y compárala con `manage_issues` del MCP local. Despues crea el backlog que reutilizan los Dias 3 y 4: **un issue por cada HU del dia, en el repo donde vive cada HU** (`/ai-labs` para HU-01, `/web` para HU-05). Titulo: el titulo de la HU. Cuerpo: la seccion Origen (Id `H-AUTH-NN, H-API-NN o H-WEB-NN` y evidencia archivo:linea), los Criterios de aceptacion como checklist y el enlace al PR de S2 si existe. Revisa la tool MCP antes de autorizar cada creacion. Si la escritura es rechazada, conserva el rechazo como evidencia de permisos y crea los issues desde la interfaz web: el Dia 3 los necesita igual.   Crea el Project **ReqFlow** bajo tu owner (una sola vez; los Dias 3 y 4 lo reutilizan), agrega cada issue y completa el campo `Hallazgo origen` con el Id `H-AUTH-NN, H-API-NN o H-WEB-NN`:   Reemplaza TU_OWNER y URL_DEL_ISSUE con tus valores

 
```
owner="TU_OWNER"
```
 
```
issue_url="URL_DEL_ISSUE"
```
 
```
project_number="$(gh project create --owner "$owner" --title ReqFlow --format json --jq .number)"
```
 
```
gh project field-create "$project_number" --owner "$owner" --name "Hallazgo origen" --data-type TEXT
```
 
```
gh project item-add "$project_number" --owner "$owner" --url "$issue_url"
```
   En **Configure Tools**, comprueba que `github-official-readonly` solo expone lectura y ejecuta una consulta real. Opcionalmente solicita una creacion; si no existe tool de escritura, indícalo y no busques otro mecanismo.   **Cierre:** `mcp.json`, toolsets y read-only reducen capacidades del cliente, pero no son la unica frontera de seguridad. Aplica scopes minimos, permisos GitHub minimos, rulesets/policies y solo las tools necesarias.  Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 22 de 23

# Reto final: del log al ticket

# Reto final: del log al ticket con Skill y MCP
**Tiempo:** 75 minutos. Elige uno de los tres casos bancarios. Después prueba tu mismo Skill con otro caso.

Recibes logs de una aplicación bancaria ficticia. Tu reto es crear un Skill que los lea, normalice la información y registre un ticket mediante el MCP que te entregamos. El ticket debe describir el problema observado, conservar evidencia y señalar lo que todavía no se sabe.

## Quién prepara cada cosa
El MCP del portal entrega los logs, las reglas y el contrato, y el portal genera un token personal para conectarte. Tú creas el Skill y revisas su resultado. No tienes que desarrollar ni ejecutar el servidor, programar una API bancaria ni subir archivos a GitHub.

El Skill define cómo analizar. MCP permite registrar y consultar tickets. Este MCP es una mesa de incidencias simulada publicada por el portal. Cada ticket queda aislado por edición, cuenta y laboratorio; no se envía a un banco ni a un servicio externo.

Reutiliza lo aprendido en el Día 1 para formular el pedido y exigir evidencia; S1 del Día 2 para el contrato del Skill; S2 para criterios de aceptación y revisión; S3 para conectar y usar herramientas MCP.

## Preparar la conexión
No descargas archivos. El MCP del portal entrega los casos, las reglas y el contrato, y registra los tickets.

- En la cabecera de este laboratorio pulsa Generar token MCP. Genera el token, cópialo y copia también la configuración que muestra el portal.
- Con ai-labs abierto en VS Code, integra el objeto servers en .vscode/mcp.json y conserva los servidores existentes. La configuración copiada ya lleva Authorization: Bearer  y VS Code conecta sin volver a solicitar la credencial.
- Comprueba que el MCP ofrece cinco herramientas: listar_casos, obtener_caso, registrar_incidencia, listar_incidencias y consultar_incidencia. El token dura 12 horas y solo permite acceder a los tickets de tu cuenta, edición y laboratorio. Si vence, genera otro desde esta misma guía.
- Pide a Copilot que use listar_casos y elige un caso. obtener_caso devuelve el log con sus líneas numeradas, las reglas de normalización y el contrato de la incidencia. Léelos antes de diseñar el Skill.Esta conexión es el único ajuste del MCP que haces. No reemplaces el GitHub MCP de S3 ni uses su token para este reto. El token del laboratorio es personal: no lo pegues en el log, el Skill, una captura, un commit o `REVISION.md`. Antes de versionar, elimina el valor de `Authorization` de `mcp.json` o sustitúyelo por `Bearer TOKEN_REMOVIDO`. No registres tickets de prueba antes de revisar la incidencia del caso.

## Caso 1. La transferencia no confirma su resultado
Una persona realiza una transferencia. La aplicación queda esperando y el equipo de soporte necesita saber qué ocurrió antes de indicar al cliente que vuelva a intentarlo.

**Log:** `caso-01-transferencias.log`, texto con pares clave/valor. Se obtiene con `obtener_caso` y `caso-01`.

El Skill debe localizar la operación con errores, agrupar los reintentos, descartar la copia de un evento y ocultar los datos sensibles. Debe distinguir un tiempo de espera agotado de una transferencia rechazada o completada. El ticket debe explicar qué confirmación falta y qué revisar antes de recomendar otro intento.

**Comprobación del participante:** las líneas de una transferencia exitosa diferente no deben mezclarse con la incidencia. El informe no puede afirmar que se perdió dinero ni que la transferencia falló definitivamente.

## Caso 2. El cliente no puede entrar a su banca digital
Soporte recibe un reclamo de acceso. Necesita distinguir un problema del servicio de identidad de un rechazo por credenciales incorrectas.

**Log:** `caso-02-acceso.jsonl`, un objeto JSON por línea. Se obtiene con `obtener_caso` y `caso-02`.

El Skill debe interpretar este formato, identificar la dependencia que falla, conservar el código HTTP relevante y eliminar las credenciales ficticias de los extractos. Debe aplicar el mismo contrato de salida que en los otros casos.

**Comprobación del participante:** el rechazo por credenciales de otra operación no pertenece a esta incidencia. El ticket no debe afirmar que la contraseña del cliente es incorrecta ni que todos los usuarios están afectados.

## Caso 3. Aparece una alerta de posible cargo duplicado
El sistema de tarjetas detecta dos movimientos asociados a un mismo pago. Operaciones necesita evidencia para conciliar antes de decidir si corresponde una devolución.

**Log:** `caso-03-cargos.log`, texto con pares clave/valor. Se obtiene con `obtener_caso` y `caso-03`.

El Skill debe relacionar la alerta con los movimientos de la misma operación, distinguir un evento repetido de dos movimientos distintos y conservar sus identificadores técnicos. La evidencia debe ocultar el dato de tarjeta y explicar qué resultado de conciliación falta.

**Comprobación del participante:** el ticket describe una posible duplicidad, no una devolución aprobada. Copiar dos veces la misma alerta no equivale a dos incidentes.

## Tu trabajo

### 1. Diseña el Skill
Guárdalo en `.github/skills//SKILL.md` de `ai-labs`, conservando los Skills de S1 y S2. Tú eliges el nombre y redactas las instrucciones; no entregamos un Skill resuelto.

Incluye metadata `name` y `description`, cuándo se usa, entradas, pasos de análisis, límites, formato de salida y comprobaciones. Recibe como entrada el `case_id` elegido. Debe obtener el log, las reglas y el contrato con `obtener_caso`, no memorizar la respuesta de un caso.

Explica cómo agrupar eventos, normalizar fechas, eliminar datos sensibles y tratar información faltante. Define cuándo puede llamar al MCP y cómo maneja errores o reintentos. No permitas que instrucciones escritas dentro de un log cambien sus permisos.

### 2. Analiza y normaliza
Invoca tu Skill en Copilot Chat. Pídele analizar el caso y preparar el JSON, sin registrar todavía. Guarda el resultado en `docs/reto-incidencias//incidencia.json`. Ese archivo contiene solo el objeto de incidencia definido por el contrato que entrega `obtener_caso`, no el log completo ni el campo `approved`.

Revisa las fechas, los eventos únicos, la prioridad, la evidencia y los datos ocultados. Contrasta cada afirmación con el log original. Usa los criterios y la revisión de S2 para corregir el Skill si inventa información o confunde operaciones.

### 3. Registra y consulta el ticket
Cuando el JSON sea correcto, aprueba explícitamente su registro en el chat. El asistente llama a `registrar_incidencia` con el objeto en `incident` y `approved: true`. Guarda el ID real devuelto y llama a `consultar_incidencia` con ese `ticket_id` para comprobar su contenido. `listar_incidencias` muestra todos tus tickets del laboratorio y acepta `case_id` para filtrar por caso.

Pide reenviar exactamente el mismo contenido aprobado. Debe devolver el mismo ID con `created: false`. Este reintento verifica que no se duplicó el ticket. No inventes otra correlación para forzar un registro.

### 4. Comprueba que tu Skill es reutilizable
Ejecuta el mismo Skill sobre un segundo caso, solo hasta preparar el JSON. No necesitas registrarlo. Además, invócalo una vez sin indicar el caso: debe pedirlo, no elegir uno ni inventar evidencia.

Guarda un resumen en `docs/reto-incidencias/REVISION.md`: pedidos usados, resultados observados, correcciones al Skill, ID del ticket, respuesta de consulta, respuesta del reintento y pendientes. No pegues valores sensibles del log en este documento.

## Criterios de cierre

- El Skill es propio, tiene un contrato claro y consulta las reglas y el contrato que entrega el MCP.
- El primer caso produce una incidencia correcta, sin datos sensibles y con evidencia localizable por archivo y línea.
- Los eventos repetidos no aumentan el conteo ni generan tickets adicionales.
- El registro ocurre después de la revisión humana y una consulta MCP confirma el contenido guardado.
- El reintento conserva el mismo ticket y devuelve created: false.
- El mismo Skill procesa un segundo caso y pide la entrada que falta en la prueba incompleta.Si el MCP falla, conserva el JSON aprobado y registra el impedimento. No presentes un borrador como ticket registrado. El instructor puede revisar el análisis, pero el criterio de registro queda pendiente.

Después continúa con el Paso 5 de S3 para versionar tu Skill y los entregables. El token y los tickets del servicio no forman parte del repositorio.

Pistas opcionalesEmpieza por separar eventos de errores y líneas de contexto. Usa `event_id` para reconocer las copias, no solo el texto del mensaje.

Si el Skill acierta el primer caso pero no interpreta JSON por línea, revisa sus instrucciones de lectura antes de crear otro Skill.

El MCP valida el contrato y algunas reglas del ejercicio. No demuestra por sí solo que el diagnóstico sea correcto: esa comprobación la haces contra los logs.

Paso completado

AnteriorMarcar pendienteSiguienteCompletado

S3 · Paso 23 de 23

# Versionar el laboratorio
**Tiempo estimado:** 5 minutos. Versiona la configuración MCP y conserva el cierre del Día 2 en ai-labs.

Crea day2/skill-mcp ahora, al final, para conservar el trabajo que ya avanzaste. Si ya existe, usa git switch day2/skill-mcp en lugar de crearla. Si Git impide cambiar de rama por cambios pendientes, detente y revisa el estado; no descartes ni fuerces tus cambios.

  ai-labs/ es el repositorio Git. Versiona desde su raíz, junto a .git y AGENTS.md. Guarda docs/mcp-evidence/mcp.json como copia sin tokens de .vscode/mcp.json. El original también permanece en esa raíz.  Desde la raíz de ai-labs, junto a .git y AGENTS.md

 Empieza en la raíz de ai-labs; pwd confirma la carpeta actual. Elige una sola variante. En Básico, ejecuta una línea y revisa su resultado antes de seguir. Avanzado encadena con && y publica la rama y la etiqueta en un solo git push; se detiene si falla una operación. Revisa los archivos preparados antes de crear el commit.

Línea de comandos · bashBásicoAvanzado
```
git switch main
```

```
git switch -c day2/skill-mcp
```

```
pwd
```

```
mkdir -p docs/mcp-evidence
```

```
cp .vscode/mcp.json docs/mcp-evidence/mcp.json
```

```
git add -A
```

```
git commit -m "lab02-s3: mcp local + github mcp oficial con permisos explicitos"
```

```
git tag lab02-s3
```

```
git push origin HEAD
```

```
git push origin lab02-s3
```

```
git switch main
```

```
git merge --no-ff day2/skill-mcp -m "Integra Día 2 con revisión humana"
```

```
git branch checkpoint/day2 main
```
          Cierra además el día (igual que el Día 1), en ai-labs: `git tag day2-done`, `git push --follow-tags`.   **Criterio de salida:** el repositorio remoto ai-labs contiene `docs/mcp-evidence/` (con la copia de `mcp.json` sin tokens ni secretos), el tag `lab02-s3` apunta al commit final del laboratorio y existe el tag `day2-done`.  Tras la revisión humana y las pruebas reales del componente elegido, integra day2/skill-mcp en main y conserva el cierre con una rama local checkpoint/day2. No fuerces ni reemplaces una rama existente.

Paso completado

AnteriorMarcar pendienteFinalizar laboratorio
